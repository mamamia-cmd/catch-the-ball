
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let paddle = { x: 150, width: 100, height: 20, y: canvas.height - 30 };
let ball = { x: Math.random() * 350, y: 0, radius: 15, speed: 4 };
let score = 0;

function drawPaddle() {
  ctx.fillStyle = "#00ff99";
  ctx.fillRect(paddle.x, paddle.y, paddle.width, paddle.height);
}

function drawBall() {
  ctx.beginPath();
  ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
  ctx.fillStyle = "#ff5050";
  ctx.fill();
  ctx.closePath();
}

function drawScore() {
  ctx.fillStyle = "#fff";
  ctx.font = "20px Arial";
  ctx.fillText("Score: " + score, 10, 30);
}

function update() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawPaddle();
  drawBall();
  drawScore();

  ball.y += ball.speed;

  if (
    ball.y + ball.radius >= paddle.y &&
    ball.x >= paddle.x &&
    ball.x <= paddle.x + paddle.width
  ) {
    score++;
    ball.y = 0;
    ball.x = Math.random() * 350;
  }

  if (ball.y > canvas.height) {
    alert("Game Over! Your score: " + score);
    document.location.reload();
  }

  requestAnimationFrame(update);
}

document.addEventListener("mousemove", (e) => {
  let rect = canvas.getBoundingClientRect();
  paddle.x = e.clientX - rect.left - paddle.width / 2;
});

update();
